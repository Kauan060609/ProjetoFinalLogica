import java.util.ArrayList;
import java.util.Scanner;

import exception.CodigoDuplicadoException;
import model.Equipamento;
import model.Manutencao;
import model.Tecnico;

public class Main {
    public static void main(String[] args) throws Exception {
        
        Scanner sc = new Scanner(System.in);
        ArrayList <Equipamento> listaEquipamentos = new ArrayList<>();
        ArrayList <Tecnico> listaTecnicos = new ArrayList<>();
        ArrayList <Manutencao> listaManutencaos = new ArrayList<>();
        int escolhaInicial = 0;

        while(escolhaInicial != 10){

            System.out.println("1-Equipamentos\n2-Técnicos\n3-Manutenções");
            int escolha = sc.nextInt();
            sc.nextLine();

            switch (escolha) {
                case 1:
                    System.out.println("===MENU EQUIPAMENTOS===");
                    System.out.println("1-Cadastrar Equipamento\n2-Consultar por Código\n3-Alterar Informações\n4-Excluir Equipamento\n5-Listar Equipamentos");
                    int escolhaEquipamento = sc.nextInt();
                    sc.nextLine();

                    switch (escolhaEquipamento) {

                       
                        case 1:
                            try{
                            System.out.println("Código:  ");
                            int codigo = sc.nextInt();
                            sc.nextLine();
                            if(listaEquipamentos.stream().anyMatch(e -> e.getCodigo() == codigo) == true){
                                throw new CodigoDuplicadoException("O código já existe na base de dados!");
                            }
                            System.out.println("Nome: ");
                            String nome = sc.nextLine();
                            System.out.println("Categoria: ");
                            String categoria = sc.nextLine();
                            System.out.println("Fabricante: ");
                            String fabricante = sc.nextLine();
                            System.out.println("Modelo:  ");
                            String modelo = sc.nextLine();
                            System.out.println("Setor instalado: ");
                            String setorInstalado = sc.nextLine();
                            System.out.println("Data Instalação: ");
                            String dataInstalacao = sc.nextLine();
                            System.out.println("Status(Operando, Em manutenção ou Inativo): ");
                            String status = sc.nextLine();

                            Equipamento e1 = new Equipamento(codigo, nome, categoria, fabricante, modelo, setorInstalado, dataInstalacao, status);
                            listaEquipamentos.add(e1);
                            }catch(CodigoDuplicadoException erro){
                                System.out.println("Erro - " + erro.getMessage());
                            }
                            break;

                        case 2:
                            System.out.println("Código Buscado: ");
                            int codigoProcurado = sc.nextInt();
                            sc.nextLine();
                            listaEquipamentos.i
                            break;

                        case 3:
                            
                            break;
                        
                        case 4:
                            
                            break;

                        case 5:
                            
                            break;
                    
                        default:
                            System.out.println("Escolha Inválida!");
                            break;
                    }
                    break;
                    
                case 2:
                    System.out.println("===MENU TÉCNICOS===");
                    break;
                
                case 3:
                    System.out.println("===MENU MANUTENÇÕES===");
                    break;

                default:
                    System.out.println("Escolha Inválida!");
                    break;


            }
        }
    }
}
